package capstone1;
import javax.swing.JOptionPane;
import java.util.Random;
public class capstone1 {

	 public static void main(String[] args) {
	        String[] deckOfCards;
	        String[] shuffledDeckOfCards;

	        deckOfCards = theDeck();
	        displayTheDeck(deckOfCards);
	        shuffledDeckOfCards = shuffleTheDeck(deckOfCards);
	        displayTheDeck(shuffledDeckOfCards);
	    }

	    public static String[] theDeck() {
	        String[] theDeck;

	        theDeck = createDeck(52);

	        theDeck = numbertTheCards(theDeck);

	        theDeck = addNumberValueToEachCard(theDeck);

	        theDeck = addPicturesAndAcesToCards(theDeck);

	        theDeck = addSuitsToCards(theDeck);

	        return theDeck;
	    }

	    public static String[] createDeck(int numCards) {
	        String[] theDeck = new String[numCards];
	        return theDeck;
	    }

	    public static String[] numbertTheCards(String[] theDeck) {
	        for (int n = 0; n < theDeck.length; n++) {
	            theDeck[n] = Integer.toString(n);
	        }
	        return theDeck;
	    }

	    public static String[] addNumberValueToEachCard(String[] theDeck) {
	        int n = 0;
	        while (n < theDeck.length) {
	            theDeck[n] = Integer.toString(Integer.parseInt(theDeck[n]) + 1);
	            n++;
	        }
	        return theDeck;
	    }

	    public static String[] addPicturesAndAcesToCards(String[] theDeck) {
	        int n = 0;
	        do {
	            switch (Integer.parseInt(theDeck[n]) % 13) {
	                case 1:
	                    theDeck[n] = "ace";
	                    break;
	                case 11:
	                    theDeck[n] = "jack";
	                    break;
	                case 12:
	                    theDeck[n] = "queen";
	                    break;
	                case 0:
	                    theDeck[n] = "king";
	                    break;
	                default:
	                    theDeck[n] = Integer.toString(Integer.parseInt(theDeck[n]) % 13);
	                    break;
	            }
	            n++;
	        } while (n < theDeck.length);
	        return theDeck;
	    }

	    public static String[] addSuitsToCards(String[] theDeck) {
	        int numCardsInASuit = 13;

	        for (int n = 0; n < theDeck.length; n++) {
	            if (n / numCardsInASuit == 0) {
	                theDeck[n] = theDeck[n] + " " + "clubs";
	            } else if (n / numCardsInASuit == 1) {
	                theDeck[n] = theDeck[n] + " " + "diamonds";
	            } else if (n / numCardsInASuit == 2) {
	                theDeck[n] = theDeck[n] + " " + "hearts";
	            } else if (n / numCardsInASuit == 3) {
	                theDeck[n] = theDeck[n] + " " + "spades";
	            }
	        }
	        return theDeck;
	    }

	    public static void displayTheDeck(String[] theDeck) {
	        String outputString = "\n";
	        if (theDeck == null || theDeck.length == 0) {
	            outputString = "empty deck";
	            JOptionPane.showMessageDialog(null, outputString);
	            return;
	        }

	        for (int n = 0; n < theDeck.length; n++) {
	            if (n % 13 == 0 && n != 0) {
	                outputString += "\n";
	            }
	            outputString += theDeck[n] + "  ";
	        }

	        System.out.println(outputString);
	    }

	    public static String[] shuffleTheDeck(String[] theDeck) {
	        Random rand = new Random();
	        String[] theShuffledDeck = new String [theDeck.length];
	        
	        for (int n = 0; n< theDeck.length; n++) {
	        	int p = rand.nextInt();
	        	p = p *100000;
	        	if (p<0)
	        	{
	        		p = -1 * p;
	        	}
	        	p = p % theDeck.length;
	        	System.out.println(p);
	        	
	        	while(theDeck[p].equals("-1"))
	        	{
	        		p++;
	        		
	        		if(p == theDeck.length)
	        		{
	        			p = 0;
	        		}
	        	}
	        	theShuffledDeck[n] = theDeck[p];
	        	theDeck[p] = "-1";
	        }
	        return theShuffledDeck;
	    }
}